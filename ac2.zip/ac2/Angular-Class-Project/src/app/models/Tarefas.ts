export interface Tarefas {
    id: number;
    descricao: string;
    concluida: boolean;

}