export interface produto {
    id: number;
    nome: string;
    preco: string;
    descricao: string;
    emEstoque: boolean;
    status: string;
}