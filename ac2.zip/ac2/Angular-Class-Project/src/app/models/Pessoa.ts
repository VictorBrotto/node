export interface Pessoa { 
    id : number;
    nome : string;
    cidade : string;
    celular : string;

}