 export interface Usuario{
    nome: String;
    email: String;
    senha: String;
    ativo: Boolean;
    id: number;
 }
