import { Component } from '@angular/core';

@Component({
  selector: 'app-pagina-nao-encontrada',
  imports: [],
  templateUrl: './pagina-nao-encontrada.component.html',
  styleUrl: './pagina-nao-encontrada.component.css'
})
export class PaginaNaoEncontradaComponent {

}
